# Blazor Server with EF Core Sample App

This sample illustrates the use of Blazor Server EF Core scenarios described in the Blazor documentation.
