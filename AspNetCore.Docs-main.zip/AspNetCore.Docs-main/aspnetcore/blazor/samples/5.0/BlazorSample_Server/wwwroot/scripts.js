﻿export function showPrompt(message) {
  return prompt(message, 'Type anything here');
}
